﻿namespace SimpleApiTemplateDotNet8
{
    public class Class1
    {

    }
}
