﻿namespace SimpleApiTemplateDotNet8.Data.Dtos;

public class BaseDto
{

}