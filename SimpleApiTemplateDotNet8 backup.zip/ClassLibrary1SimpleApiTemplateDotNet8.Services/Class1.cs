﻿namespace ClassLibrary1SimpleApiTemplateDotNet8.Services;

public class Class1
{
}