﻿using System.ComponentModel.DataAnnotations;

namespace SimpleApiTemplateDotNet8.Models.Base;

public abstract class BaseEntity
{

}
